import type { ReactNode } from 'react';
import { cn } from '@/lib/cn';

export type Column<T> = { key: string; header: string; cell: (row: T) => ReactNode; align?: 'right'; className?: string };

export function DataTable<T>({ columns, rows, rowKey, caption }: {
  columns: Column<T>[]; rows: T[]; rowKey: (row: T) => string; caption?: string;
}) {
  return (
    <div className="overflow-x-auto rounded-lg border border-line">
      <table className="w-full min-w-[36rem] text-left text-sm">
        {caption && <caption className="sr-only">{caption}</caption>}
        <thead className="border-b border-line bg-surface-2 text-xs uppercase tracking-wider text-muted">
          <tr>
            {columns.map((c) => (
              <th key={c.key} scope="col" className={cn('px-4 py-3 font-medium', c.align === 'right' && 'text-right', c.className)}>{c.header}</th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-line">
          {rows.map((r) => (
            <tr key={rowKey(r)} className="hover:bg-surface-2/60">
              {columns.map((c) => (
                <td key={c.key} className={cn('px-4 py-3', c.align === 'right' && 'text-right tnum', c.className)}>{c.cell(r)}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
