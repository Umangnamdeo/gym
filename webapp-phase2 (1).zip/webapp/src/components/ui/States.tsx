import type { ReactNode } from 'react';
import { Card } from './Card';

export function EmptyState({ title, description, action }: { title: string; description?: string; action?: ReactNode }) {
  return (
    <Card className="flex flex-col items-center gap-2 py-10 text-center">
      <p className="font-display text-xl font-semibold uppercase tracking-wide">{title}</p>
      {description && <p className="max-w-sm text-sm text-muted">{description}</p>}
      {action && <div className="mt-2">{action}</div>}
    </Card>
  );
}

export function ErrorState({ title = 'Something went wrong', message, action }: { title?: string; message?: string; action?: ReactNode }) {
  return (
    <Card role="alert" className="flex flex-col items-center gap-2 border-danger/40 py-10 text-center">
      <p className="font-display text-xl font-semibold uppercase tracking-wide text-danger">{title}</p>
      {message && <p className="max-w-sm text-sm text-muted">{message}</p>}
      {action && <div className="mt-2">{action}</div>}
    </Card>
  );
}
