import { formatDate } from '@/lib/format';
import type { MembershipState } from '@/lib/types';
import { MembershipStatusBadge } from './Badge';
import { Card, CardTitle } from './Card';

export function MembershipCard({ planName, startDate, expiryDate, state, daysRemaining }: {
  planName?: string | null; startDate?: string | null; expiryDate?: string | null;
  state: MembershipState; daysRemaining?: number | null;
}) {
  const showDays = state === 'active' && daysRemaining != null && daysRemaining >= 0;
  return (
    <Card>
      <div className="flex items-center justify-between">
        <CardTitle>Membership</CardTitle>
        <MembershipStatusBadge state={state} daysRemaining={daysRemaining} />
      </div>
      <p className="tnum mt-4 font-display text-6xl font-semibold leading-none">
        {showDays ? daysRemaining : '—'}
        <span className="ml-2 text-xl uppercase tracking-widest text-muted">{showDays ? 'days left' : ''}</span>
      </p>
      <dl className="mt-5 grid grid-cols-3 gap-3 border-t border-line pt-4 text-sm">
        <div><dt className="text-[11px] uppercase tracking-wider text-muted">Plan</dt><dd className="mt-1 font-medium">{planName ?? '—'}</dd></div>
        <div><dt className="text-[11px] uppercase tracking-wider text-muted">Started</dt><dd className="mt-1 font-medium">{startDate ? formatDate(startDate) : '—'}</dd></div>
        <div><dt className="text-[11px] uppercase tracking-wider text-muted">Expires</dt><dd className="mt-1 font-medium">{expiryDate ? formatDate(expiryDate) : '—'}</dd></div>
      </dl>
    </Card>
  );
}
