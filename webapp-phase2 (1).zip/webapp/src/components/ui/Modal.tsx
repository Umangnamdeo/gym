'use client';

import { useEffect, useId, useRef, type ReactNode } from 'react';
import { Button } from './Button';

export function Modal({ open, onClose, title, children, footer }: {
  open: boolean; onClose: () => void; title: string; children: ReactNode; footer?: ReactNode;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const titleId = useId();

  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    if (open && !d.open) d.showModal();
    if (!open && d.open) d.close();
  }, [open]);

  return (
    // Native <dialog>: focus trap, Esc to close and inert background come from the browser.
    <dialog
      ref={ref}
      onClose={onClose}
      onClick={(e) => { if (e.target === ref.current) onClose(); }}
      aria-labelledby={titleId}
      className="m-auto w-[calc(100%-2rem)] max-w-md rounded-lg border border-line bg-surface p-0 text-fg backdrop:bg-black/70"
    >
      <div className="p-5">
        <h2 id={titleId} className="font-display text-2xl font-semibold uppercase tracking-wide">{title}</h2>
        <div className="mt-3 text-sm text-muted">{children}</div>
      </div>
      {footer && <div className="flex justify-end gap-2 border-t border-line p-3">{footer}</div>}
    </dialog>
  );
}

export function ConfirmDialog({ open, title, message, confirmLabel = 'Confirm', tone = 'primary', loading = false, onConfirm, onCancel }: {
  open: boolean; title: string; message: string; confirmLabel?: string; tone?: 'primary' | 'danger';
  loading?: boolean; onConfirm: () => void; onCancel: () => void;
}) {
  return (
    <Modal open={open} onClose={onCancel} title={title}
      footer={<>
        <Button variant="ghost" onClick={onCancel} disabled={loading}>Cancel</Button>
        <Button variant={tone} onClick={onConfirm} loading={loading}>{confirmLabel}</Button>
      </>}>
      {message}
    </Modal>
  );
}
