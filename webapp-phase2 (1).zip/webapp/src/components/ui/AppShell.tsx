import type { ReactNode } from 'react';
import type { NavItem } from '@/lib/nav';
import { Brand } from './Brand';
import { Button } from './Button';
import { MobileNav, SidebarNav } from './Nav';

function SignOut() {
  return (
    <form action="/logout" method="post">
      <Button type="submit" variant="ghost" size="sm">Sign out</Button>
    </form>
  );
}

export function AppShell({ items, userName, roleLabel, children }: {
  items: NavItem[]; userName: string; roleLabel: string; children: ReactNode;
}) {
  return (
    <div className="min-h-dvh lg:grid lg:grid-cols-[15rem_1fr]">
      <aside className="no-print hidden border-r border-line bg-surface lg:block">
        <div className="sticky top-0 flex h-dvh flex-col">
          <div className="border-b border-line p-5"><Brand /></div>
          <div className="flex-1 overflow-y-auto"><SidebarNav items={items} /></div>
          <div className="flex items-center justify-between border-t border-line p-3">
            <div className="min-w-0">
              <p className="truncate text-sm font-medium">{userName}</p>
              <p className="text-[11px] uppercase tracking-wider text-muted">{roleLabel}</p>
            </div>
            <SignOut />
          </div>
        </div>
      </aside>

      <div className="flex min-w-0 flex-col">
        <header className="no-print sticky top-0 z-30 flex h-14 items-center justify-between border-b border-line bg-bg/95 px-4 lg:hidden">
          <Brand />
          <SignOut />
        </header>
        <main className="mx-auto w-full max-w-6xl flex-1 p-4 pb-24 lg:p-8">{children}</main>
      </div>

      <MobileNav items={items} />
    </div>
  );
}

export function PageHeader({ title, description, actions }: { title: string; description?: string; actions?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="font-display text-4xl font-bold uppercase leading-none tracking-wide">{title}</h1>
        {description && <p className="mt-2 text-sm text-muted">{description}</p>}
      </div>
      {actions && <div className="flex gap-2">{actions}</div>}
    </div>
  );
}
