import type { ReactNode } from 'react';
import { cn } from '@/lib/cn';
import { SCAN_LABEL, SCAN_OK, type ScanOutcome } from '@/lib/scan-codes';
import { SegmentedControl } from './SegmentedControl';

export function ScanResult({ outcome }: { outcome: ScanOutcome | null }) {
  if (!outcome) {
    return (
      <div aria-live="polite" className="rounded-lg border border-line bg-surface p-6 text-center">
        <p className="font-display text-3xl font-semibold uppercase tracking-widest text-muted">Ready to scan</p>
      </div>
    );
  }
  const ok = SCAN_OK[outcome.code];
  return (
    <div role={ok ? 'status' : 'alert'} aria-live="assertive"
      className={cn('rounded-lg border-2 p-6 text-center', ok ? 'border-ok bg-ok/10' : 'border-danger bg-danger/10')}>
      <p className={cn('font-display text-4xl font-bold uppercase leading-none tracking-wide', ok ? 'text-ok' : 'text-danger')}>
        {SCAN_LABEL[outcome.code]}
      </p>
      {outcome.name && <p className="mt-3 text-lg font-medium">{outcome.name}</p>}
      {outcome.memberId && <p className="text-xs tracking-[0.25em] text-muted">{outcome.memberId}</p>}
      {ok && outcome.daysLeft != null && (
        <p className="mt-2 text-sm text-muted">{outcome.daysLeft} days of membership left</p>
      )}
    </div>
  );
}

// Layout only. The camera view goes in `children` (Phase 10).
export function ScannerFrame({ mode, onModeChange, outcome, children }: {
  mode: 'entry' | 'exit'; onModeChange: (m: 'entry' | 'exit') => void; outcome: ScanOutcome | null; children: ReactNode;
}) {
  return (
    <div className="mx-auto w-full max-w-md space-y-3">
      <SegmentedControl label="Scan mode" value={mode} onChange={onModeChange}
        options={[{ value: 'entry', label: 'Entry' }, { value: 'exit', label: 'Exit' }]} />
      <div className="aspect-square overflow-hidden rounded-lg border border-line bg-black">{children}</div>
      <ScanResult outcome={outcome} />
    </div>
  );
}
