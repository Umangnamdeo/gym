import type { ReactNode } from 'react';
import { cn } from '@/lib/cn';
import type { MembershipState } from '@/lib/types';

type Tone = 'neutral' | 'accent' | 'ok' | 'warn' | 'danger';

const TONE: Record<Tone, string> = {
  neutral: 'border-line text-muted',
  accent: 'border-accent/40 bg-accent/10 text-accent',
  ok: 'border-ok/40 bg-ok/10 text-ok',
  warn: 'border-warn/40 bg-warn/10 text-warn',
  danger: 'border-danger/40 bg-danger/10 text-danger',
};

export function Badge({ tone = 'neutral', children, className }: { tone?: Tone; children: ReactNode; className?: string }) {
  return (
    <span className={cn('inline-flex items-center rounded-sm border px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wider', TONE[tone], className)}>
      {children}
    </span>
  );
}

// Membership state is derived by the database (member_overview view); this only maps it to a look.
export function membershipBadge(state: MembershipState, daysRemaining?: number | null): { tone: Tone; label: string } {
  switch (state) {
    case 'active':
      if (daysRemaining != null && daysRemaining <= 0) return { tone: 'warn', label: 'Expires today' };
      if (daysRemaining != null && daysRemaining <= 7) return { tone: 'warn', label: `Expires in ${daysRemaining}d` };
      return { tone: 'ok', label: 'Active' };
    case 'expired': return { tone: 'danger', label: 'Expired' };
    case 'upcoming': return { tone: 'neutral', label: 'Upcoming' };
    case 'disabled': return { tone: 'neutral', label: 'Disabled' };
    default: return { tone: 'neutral', label: 'No membership' };
  }
}

export function MembershipStatusBadge({ state, daysRemaining }: { state: MembershipState; daysRemaining?: number | null }) {
  const { tone, label } = membershipBadge(state, daysRemaining);
  return <Badge tone={tone}>{label}</Badge>;
}
