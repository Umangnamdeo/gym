export function Brand() {
  return (
    <div className="leading-none">
      <p className="font-display text-xl font-bold uppercase tracking-widest">The Muscle School</p>
      <p className="mt-1 text-[10px] font-medium uppercase tracking-[0.3em] text-muted">Sahil Fitness</p>
    </div>
  );
}
