import { formatDate, formatINR } from '@/lib/format';

export type ReceiptView = {
  number: string; date: string;
  memberName: string; memberId: string; phone?: string | null;
  planName?: string | null; startDate?: string | null; expiryDate?: string | null;
  description: string; amount: number; authorizedBy: string; notes?: string | null; voided?: boolean;
};

export type ReceiptBrand = {
  gymName: string; address: string; phone?: string | null; logo?: string | null;
  footer?: string | null; terms?: string | null;
};

// Always paper-white (screen and print). A4 width, readable on a phone.
export function ReceiptDocument({ brand, receipt }: { brand: ReceiptBrand; receipt: ReceiptView }) {
  const [line1, line2] = brand.gymName.split(' - ');
  return (
    <article className="mx-auto w-full max-w-[210mm] bg-white p-6 text-black sm:p-10 print:max-w-none print:p-0">
      <header className="border-b-2 border-black pb-4 text-center">
        {brand.logo && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={brand.logo} alt="" className="mx-auto mb-2 h-14 w-auto" />
        )}
        <h1 className="font-display text-3xl font-bold uppercase leading-none tracking-widest">{line1}</h1>
        {line2 && <p className="mt-1 text-xs font-medium uppercase tracking-[0.3em]">{line2}</p>}
        <p className="mt-2 text-xs">{brand.address}</p>
        {brand.phone && <p className="text-xs">Phone: {brand.phone}</p>}
      </header>

      <div className="mt-5 flex items-end justify-between gap-4">
        <h2 className="font-display text-2xl font-bold uppercase tracking-widest">Receipt</h2>
        <dl className="text-right text-sm">
          <div><dt className="inline text-neutral-600">No: </dt><dd className="tnum inline font-semibold">{receipt.number}</dd></div>
          <div><dt className="inline text-neutral-600">Date: </dt><dd className="inline font-semibold">{formatDate(receipt.date)}</dd></div>
        </dl>
      </div>

      {receipt.voided && (
        <p className="mt-4 border-2 border-red-700 p-2 text-center font-bold uppercase tracking-widest text-red-700">Void</p>
      )}

      <section className="mt-5 grid gap-4 text-sm sm:grid-cols-2">
        <div>
          <h3 className="text-[11px] font-semibold uppercase tracking-wider text-neutral-600">Member</h3>
          <p className="mt-1 font-semibold">{receipt.memberName}</p>
          <p>ID: {receipt.memberId}</p>
          {receipt.phone && <p>Phone: {receipt.phone}</p>}
        </div>
        {receipt.planName && (
          <div>
            <h3 className="text-[11px] font-semibold uppercase tracking-wider text-neutral-600">Membership</h3>
            <p className="mt-1 font-semibold">{receipt.planName}</p>
            {receipt.startDate && <p>Start: {formatDate(receipt.startDate)}</p>}
            {receipt.expiryDate && <p>Expiry: {formatDate(receipt.expiryDate)}</p>}
          </div>
        )}
      </section>

      <section className="mt-6 border-y border-black">
        <div className="flex justify-between gap-4 py-3 text-sm">
          <p className="min-w-0 flex-1">{receipt.description}</p>
          <p className="tnum font-semibold">{formatINR(receipt.amount)}</p>
        </div>
      </section>
      <p className="mt-3 flex justify-between text-lg font-bold">
        <span className="uppercase tracking-widest">Amount</span>
        <span className="tnum">{formatINR(receipt.amount)}</span>
      </p>

      {receipt.notes && (
        <section className="mt-5 text-sm">
          <h3 className="text-[11px] font-semibold uppercase tracking-wider text-neutral-600">Notes</h3>
          <p className="mt-1 whitespace-pre-line">{receipt.notes}</p>
        </section>
      )}

      <div className="mt-12 flex justify-end">
        <div className="w-56 border-t border-black pt-1 text-center text-xs">
          Authorized by<br /><span className="font-semibold">{receipt.authorizedBy}</span>
        </div>
      </div>

      {brand.terms && <p className="mt-8 whitespace-pre-line text-[11px] text-neutral-600">{brand.terms}</p>}
      {brand.footer && <p className="mt-4 border-t border-neutral-300 pt-3 text-center text-xs text-neutral-600">{brand.footer}</p>}
    </article>
  );
}
