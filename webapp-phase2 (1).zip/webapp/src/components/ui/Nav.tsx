'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useState } from 'react';
import { cn } from '@/lib/cn';
import type { NavItem } from '@/lib/nav';
import { Icon } from './Icon';

function useIsActive() {
  const pathname = usePathname();
  return (href: string) => {
    const isRoot = href.split('/').filter(Boolean).length === 1; // /owner, /staff, /member match exactly
    return isRoot ? pathname === href : pathname === href || pathname.startsWith(href + '/');
  };
}

export function SidebarNav({ items }: { items: NavItem[] }) {
  const isActive = useIsActive();
  return (
    <nav aria-label="Primary" className="flex flex-col gap-1 p-3">
      {items.map((i) => (
        <Link key={i.href} href={i.href} aria-current={isActive(i.href) ? 'page' : undefined}
          className={cn('flex h-11 items-center gap-3 rounded-md px-3 text-sm font-medium transition-colors',
            isActive(i.href) ? 'bg-surface-2 text-accent' : 'text-muted hover:bg-surface-2 hover:text-fg')}>
          <Icon name={i.icon} />{i.label}
        </Link>
      ))}
    </nav>
  );
}

// Up to 5 items are shown directly; with more, the first 4 plus a "More" sheet.
export function MobileNav({ items }: { items: NavItem[] }) {
  const isActive = useIsActive();
  const pathname = usePathname();
  const [more, setMore] = useState(false);
  useEffect(() => setMore(false), [pathname]);

  const overflow = items.length > 5;
  const primary = overflow ? items.slice(0, 4) : items;
  const rest = overflow ? items.slice(4) : [];
  const tab = 'flex flex-1 flex-col items-center justify-center gap-1 py-2 text-[10px] font-medium uppercase tracking-wider';

  return (
    <>
      {more && (
        <div className="no-print fixed inset-0 z-40 lg:hidden">
          <button type="button" aria-label="Close menu" onClick={() => setMore(false)} className="absolute inset-0 bg-black/60" />
          <div className="absolute inset-x-0 bottom-[calc(3.5rem+env(safe-area-inset-bottom))] grid gap-1 border-t border-line bg-surface p-2">
            {rest.map((i) => (
              <Link key={i.href} href={i.href} aria-current={isActive(i.href) ? 'page' : undefined}
                className={cn('flex h-12 items-center gap-3 rounded-md px-3 text-sm font-medium',
                  isActive(i.href) ? 'bg-surface-2 text-accent' : 'text-fg')}>
                <Icon name={i.icon} />{i.label}
              </Link>
            ))}
          </div>
        </div>
      )}
      <nav aria-label="Primary" className="no-print fixed inset-x-0 bottom-0 z-50 flex border-t border-line bg-surface pb-[env(safe-area-inset-bottom)] lg:hidden">
        {primary.map((i) => (
          <Link key={i.href} href={i.href} aria-current={isActive(i.href) ? 'page' : undefined}
            className={cn(tab, isActive(i.href) ? 'text-accent' : 'text-muted')}>
            <Icon name={i.icon} />{i.label}
          </Link>
        ))}
        {overflow && (
          <button type="button" aria-expanded={more} onClick={() => setMore((v) => !v)}
            className={cn(tab, more || rest.some((r) => isActive(r.href)) ? 'text-accent' : 'text-muted')}>
            <Icon name="more" />More
          </button>
        )}
      </nav>
    </>
  );
}
