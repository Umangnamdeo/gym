import type { ReactNode } from 'react';
import { cn } from '@/lib/cn';
import { Card, CardTitle } from './Card';

const TONE = { default: 'text-fg', accent: 'text-accent', warn: 'text-warn', danger: 'text-danger' } as const;

export function StatCard({ label, value, hint, tone = 'default' }: {
  label: string; value: ReactNode; hint?: string; tone?: keyof typeof TONE;
}) {
  return (
    <Card>
      <CardTitle>{label}</CardTitle>
      <p className={cn('tnum mt-3 font-display text-5xl font-semibold leading-none', TONE[tone])}>{value}</p>
      {hint && <p className="mt-2 text-xs text-muted">{hint}</p>}
    </Card>
  );
}

export function OccupancyMeter({ current, capacity }: { current: number; capacity: number }) {
  const pct = capacity > 0 ? Math.min(100, Math.round((current / capacity) * 100)) : 0;
  const bar = pct >= 90 ? 'bg-danger' : pct >= 70 ? 'bg-warn' : 'bg-accent';
  return (
    <Card>
      <CardTitle>Live in gym</CardTitle>
      <div className="mt-3 flex items-end justify-between">
        <p className="tnum font-display text-6xl font-semibold leading-none">
          {current}<span className="text-3xl text-muted"> / {capacity}</span>
        </p>
        <p className="tnum font-display text-3xl font-semibold text-accent">{pct}%</p>
      </div>
      <div role="progressbar" aria-label="Gym occupancy" aria-valuemin={0} aria-valuemax={100} aria-valuenow={pct}
        className="mt-4 h-2 bg-surface-2">
        <div className={cn('h-full transition-[width] duration-300', bar)} style={{ width: `${pct}%` }} />
      </div>
    </Card>
  );
}
