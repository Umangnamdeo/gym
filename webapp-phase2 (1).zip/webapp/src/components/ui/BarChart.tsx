// Dependency-free bar chart (plain divs): light, fast, scales with its container.
export function BarChart({ data, ariaLabel, height = 160, showValues = false, labelEvery = 1 }: {
  data: { label: string; value: number }[]; ariaLabel: string; height?: number; showValues?: boolean; labelEvery?: number;
}) {
  const max = Math.max(1, ...data.map((d) => d.value));
  return (
    <div role="img" aria-label={ariaLabel}>
      <div className="flex items-stretch gap-1 border-b border-line" style={{ height }}>
        {data.map((d) => {
          const ratio = (d.value / max) * 88;
          return (
            <div key={d.label} className="relative min-w-0 flex-1">
              <div className="absolute inset-x-0 bottom-0 bg-accent/80" style={{ height: `${ratio}%` }} />
              {showValues && (
                <span className="tnum absolute inset-x-0 text-center text-[10px] text-muted" style={{ bottom: `calc(${ratio}% + 2px)` }}>
                  {d.value}
                </span>
              )}
            </div>
          );
        })}
      </div>
      <div className="mt-1 flex gap-1">
        {data.map((d, i) => (
          <span key={d.label} className="min-w-0 flex-1 truncate text-center text-[10px] text-muted">
            {i % labelEvery === 0 ? d.label : ''}
          </span>
        ))}
      </div>
    </div>
  );
}
