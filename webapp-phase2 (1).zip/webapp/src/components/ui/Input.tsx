import { useId, type InputHTMLAttributes } from 'react';
import { cn } from '@/lib/cn';

export type InputProps = InputHTMLAttributes<HTMLInputElement> & { label: string; error?: string; hint?: string };

export function Input({ label, error, hint, id, className, ...rest }: InputProps) {
  const auto = useId();
  const inputId = id ?? auto;
  const describedBy = error ? `${inputId}-error` : hint ? `${inputId}-hint` : undefined;
  return (
    <div className="space-y-1.5">
      <label htmlFor={inputId} className="block text-xs font-medium uppercase tracking-wider text-muted">{label}</label>
      <input
        id={inputId}
        aria-invalid={error ? true : undefined}
        aria-describedby={describedBy}
        className={cn(
          'h-11 w-full rounded-md border bg-surface px-3 text-base text-fg placeholder:text-muted/60',
          error ? 'border-danger' : 'border-line',
          className,
        )}
        {...rest}
      />
      {error ? <p id={`${inputId}-error`} role="alert" className="text-xs text-danger">{error}</p>
        : hint ? <p id={`${inputId}-hint`} className="text-xs text-muted">{hint}</p> : null}
    </div>
  );
}
