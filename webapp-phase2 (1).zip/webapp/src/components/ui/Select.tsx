import { useId, type SelectHTMLAttributes } from 'react';
import { cn } from '@/lib/cn';

export type SelectProps = SelectHTMLAttributes<HTMLSelectElement> & { label: string; error?: string };

export function Select({ label, error, id, className, children, ...rest }: SelectProps) {
  const auto = useId();
  const selectId = id ?? auto;
  return (
    <div className="space-y-1.5">
      <label htmlFor={selectId} className="block text-xs font-medium uppercase tracking-wider text-muted">{label}</label>
      <div className="relative">
        <select
          id={selectId}
          aria-invalid={error ? true : undefined}
          className={cn('h-11 w-full appearance-none rounded-md border bg-surface pl-3 pr-9 text-base text-fg',
            error ? 'border-danger' : 'border-line', className)}
          {...rest}
        >
          {children}
        </select>
        <svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
          className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-muted"><path d="M6 9l6 6 6-6" /></svg>
      </div>
      {error && <p role="alert" className="text-xs text-danger">{error}</p>}
    </div>
  );
}
