'use client';

import { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { Skeleton } from './Skeleton';

// White card with a quiet zone: required for reliable scanning on dark screens.
export function QrCard({ value, name, memberId, size = 256 }: { value: string; name: string; memberId: string; size?: number }) {
  const [src, setSrc] = useState<string | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let alive = true;
    setSrc(null);
    setFailed(false);
    QRCode.toDataURL(value, { errorCorrectionLevel: 'M', margin: 2, width: size * 2 })
      .then((url) => { if (alive) setSrc(url); })
      .catch(() => { if (alive) setFailed(true); });
    return () => { alive = false; };
  }, [value, size]);

  return (
    <div className="mx-auto w-full max-w-xs rounded-lg bg-white p-4 text-black">
      {src ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={src} alt={`Entry QR code for ${name}`} width={size} height={size} className="mx-auto h-auto w-full" />
      ) : failed ? (
        <p role="alert" className="flex aspect-square items-center justify-center text-center text-sm">Could not create the QR code.</p>
      ) : (
        <Skeleton className="aspect-square w-full bg-neutral-200" />
      )}
      <div className="mt-3 text-center">
        <p className="font-display text-2xl font-bold uppercase leading-none">{name}</p>
        <p className="mt-1 text-xs tracking-[0.25em]">{memberId}</p>
      </div>
    </div>
  );
}
