import type { ReactNode } from 'react';
import type { Role } from '@/lib/auth';
import { NAV } from '@/lib/nav';
import { AppShell } from '@/components/ui/AppShell';

export function RoleShell({ role, name, children }: { role: Role; name: string; children: ReactNode }) {
  return <AppShell items={NAV[role]} userName={name} roleLabel={role}>{children}</AppShell>;
}
