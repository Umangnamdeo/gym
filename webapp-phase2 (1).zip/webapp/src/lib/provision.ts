import 'server-only';
import { createAdminClient } from '@/lib/supabase/admin';
import type { Role } from '@/lib/auth';

// Account provisioning for owner-issued invites.
// Callers MUST verify the current user is the owner (requireRole('owner')) first.
// Phase 6 wires these into the member/staff forms.

type InviteInput = { email: string; fullName: string; role: Exclude<Role, 'owner'> };

export async function inviteAccount({ email, fullName, role }: InviteInput): Promise<{ userId: string }> {
  const admin = createAdminClient();

  const { data, error } = await admin.auth.admin.inviteUserByEmail(email, {
    data: { must_set_password: true },
  });
  if (error || !data.user) throw new Error(error?.message ?? 'Invite failed');

  const { error: profileError } = await admin
    .from('users')
    .insert({ id: data.user.id, role, full_name: fullName });
  if (profileError) {
    await admin.auth.admin.deleteUser(data.user.id); // roll back the half-created account
    throw new Error('Could not create profile');
  }
  return { userId: data.user.id };
}

// Roll back an invite if the follow-up members/staff insert fails.
export async function removeAccount(userId: string) {
  const admin = createAdminClient();
  await admin.auth.admin.deleteUser(userId);
}

// Disable/enable login. is_active blocks RLS immediately; the ban stops token refresh.
export async function setAccountActive(userId: string, active: boolean) {
  const admin = createAdminClient();
  const { error } = await admin.from('users').update({ is_active: active }).eq('id', userId);
  if (error) throw new Error('Could not update account');
  await admin.auth.admin.updateUserById(userId, { ban_duration: active ? 'none' : '876000h' });
}
