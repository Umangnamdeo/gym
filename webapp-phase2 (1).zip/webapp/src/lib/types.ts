export type MembershipState = 'active' | 'expired' | 'upcoming' | 'disabled' | 'none';
