import type { IconName } from '@/components/ui/Icon';
import type { Role } from '@/lib/auth';

export type NavItem = { href: string; label: string; icon: IconName };

// Only pages that exist are listed. Each phase adds its own entries:
//   member: QR, Attendance, Membership, Profile            (Phase 8)
//   staff:  Scanner, Members, Attendance                    (Phase 14)
//   owner:  Members, Attendance, Memberships, Scanner, Receipts, Analytics,
//           Reports, Notifications, Settings                (Phase 13)
export const NAV: Record<Role, NavItem[]> = {
  owner: [{ href: '/owner', label: 'Dashboard', icon: 'dashboard' }],
  staff: [{ href: '/staff', label: 'Home', icon: 'home' }],
  member: [{ href: '/member', label: 'Home', icon: 'home' }],
};
