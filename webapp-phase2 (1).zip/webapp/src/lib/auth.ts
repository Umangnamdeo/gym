import 'server-only';
import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';

export type Role = 'owner' | 'staff' | 'member';

export const ROLE_HOME: Record<Role, string> = {
  owner: '/owner',
  staff: '/staff',
  member: '/member',
};

export async function getCurrentUser() {
  const supabase = await createClient();
  // getUser() re-validates the token with Supabase; never trust getSession() for authorization
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const { data: profile } = await supabase
    .from('users')
    .select('role, full_name, is_active')
    .eq('id', user.id)
    .maybeSingle();
  if (!profile) return null;

  return {
    id: user.id,
    email: user.email ?? null,
    role: profile.role as Role,
    fullName: profile.full_name as string,
    isActive: profile.is_active as boolean,
  };
}

// The real authorization gate for pages. Middleware only handles UX redirects.
export async function requireRole(...allowed: Role[]) {
  const me = await getCurrentUser();
  if (!me) redirect('/login');
  if (!me.isActive) redirect('/unauthorized?reason=disabled');
  if (!allowed.includes(me.role)) redirect('/unauthorized');
  return me;
}
