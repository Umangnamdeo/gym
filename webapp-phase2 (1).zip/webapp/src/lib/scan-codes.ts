// Result codes returned by the record_scan database function.
export type ScanCode =
  | 'ENTRY_APPROVED' | 'EXIT_RECORDED'
  | 'QR_INVALID' | 'MEMBER_NOT_FOUND' | 'MEMBERSHIP_EXPIRED'
  | 'ALREADY_CHECKED_IN' | 'NOT_CHECKED_IN' | 'ACCOUNT_DISABLED';

export const SCAN_LABEL: Record<ScanCode, string> = {
  ENTRY_APPROVED: 'ENTRY APPROVED',
  EXIT_RECORDED: 'EXIT RECORDED',
  QR_INVALID: 'QR INVALID',
  MEMBER_NOT_FOUND: 'MEMBER NOT FOUND',
  MEMBERSHIP_EXPIRED: 'MEMBERSHIP EXPIRED',
  ALREADY_CHECKED_IN: 'ALREADY CHECKED IN',
  NOT_CHECKED_IN: 'NOT CHECKED IN',
  ACCOUNT_DISABLED: 'ACCOUNT DISABLED',
};

export const SCAN_OK: Record<ScanCode, boolean> = {
  ENTRY_APPROVED: true, EXIT_RECORDED: true,
  QR_INVALID: false, MEMBER_NOT_FOUND: false, MEMBERSHIP_EXPIRED: false,
  ALREADY_CHECKED_IN: false, NOT_CHECKED_IN: false, ACCOUNT_DISABLED: false,
};

export type ScanOutcome = { code: ScanCode; name?: string; memberId?: string; daysLeft?: number | null };
