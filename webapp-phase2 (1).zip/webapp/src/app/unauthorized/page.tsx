import { Brand } from '@/components/ui/Brand';
import { Button } from '@/components/ui/Button';

export const metadata = { title: 'Access denied' };

export default async function UnauthorizedPage({ searchParams }: { searchParams: Promise<{ reason?: string }> }) {
  const { reason } = await searchParams;
  return (
    <main className="mx-auto flex min-h-dvh max-w-sm flex-col justify-center gap-6 p-6">
      <Brand />
      <div>
        <h1 className="font-display text-3xl font-bold uppercase tracking-wide">Access denied</h1>
        <p className="mt-1 text-sm text-muted">
          {reason === 'disabled' ? 'This account has been disabled. Please contact the gym.' : 'You do not have permission to view that page.'}
        </p>
      </div>
      <form action="/logout" method="post">
        <Button type="submit" variant="secondary">Sign out</Button>
      </form>
    </main>
  );
}
