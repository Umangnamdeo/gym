import { redirect } from 'next/navigation';
import { Brand } from '@/components/ui/Brand';
import { createClient } from '@/lib/supabase/server';
import { SetPasswordForm } from './SetPasswordForm';

export const metadata = { title: 'Set your password' };

export default async function SetPasswordPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  return (
    <main className="mx-auto flex min-h-dvh max-w-sm flex-col justify-center gap-8 p-6">
      <Brand />
      <div>
        <h1 className="font-display text-3xl font-bold uppercase tracking-wide">Welcome</h1>
        <p className="mt-1 text-sm text-muted">Choose a password to finish setting up your account.</p>
      </div>
      <SetPasswordForm />
    </main>
  );
}
