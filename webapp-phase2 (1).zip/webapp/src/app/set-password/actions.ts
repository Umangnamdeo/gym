'use server';

import { redirect } from 'next/navigation';
import { z } from 'zod';
import { createClient } from '@/lib/supabase/server';
import { ROLE_HOME, type Role } from '@/lib/auth';

export type SetPasswordState = { error?: string };

const schema = z
  .object({
    password: z.string().min(10, 'Use at least 10 characters.').max(72, 'Use 72 characters or fewer.'),
    confirm: z.string(),
  })
  .refine((v) => v.password === v.confirm, { message: 'Passwords do not match.', path: ['confirm'] });

export async function setPassword(_prev: SetPasswordState, formData: FormData): Promise<SetPasswordState> {
  const parsed = schema.safeParse({ password: formData.get('password'), confirm: formData.get('confirm') });
  if (!parsed.success) return { error: parsed.error.issues[0].message };

  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  const { error } = await supabase.auth.updateUser({
    password: parsed.data.password,
    data: { must_set_password: false },
  });
  if (error) return { error: 'Could not save the password. Try a different one.' };

  const { data: profile } = await supabase.from('users').select('role').eq('id', user.id).maybeSingle();
  redirect(profile ? ROLE_HOME[profile.role as Role] : '/login');
}
