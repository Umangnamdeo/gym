'use client';

import { useActionState } from 'react';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { setPassword, type SetPasswordState } from './actions';

export function SetPasswordForm() {
  const [state, action, pending] = useActionState<SetPasswordState, FormData>(setPassword, {});
  return (
    <form action={action} className="space-y-4">
      <Input label="New password" name="password" type="password" autoComplete="new-password" minLength={10} required hint="At least 10 characters." />
      <Input label="Confirm password" name="confirm" type="password" autoComplete="new-password" minLength={10} required />
      {state.error && <p role="alert" className="text-sm text-danger">{state.error}</p>}
      <Button type="submit" size="lg" loading={pending} className="w-full">{pending ? 'Saving' : 'Save password'}</Button>
    </form>
  );
}
