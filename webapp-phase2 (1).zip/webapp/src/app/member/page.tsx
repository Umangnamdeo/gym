import { PageHeader } from '@/components/ui/AppShell';
import { EmptyState } from '@/components/ui/States';

export default function MemberHome() {
  return (
    <>
      <PageHeader title="Member" />
      <EmptyState title="Coming soon" description="This area is built in Phase 8." />
    </>
  );
}
