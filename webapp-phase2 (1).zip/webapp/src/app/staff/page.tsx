import { PageHeader } from '@/components/ui/AppShell';
import { EmptyState } from '@/components/ui/States';

export default function StaffHome() {
  return (
    <>
      <PageHeader title="Staff" />
      <EmptyState title="Coming soon" description="This area is built in Phase 14." />
    </>
  );
}
