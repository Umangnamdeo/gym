import type { ReactNode } from 'react';
import { requireRole } from '@/lib/auth';
import { RoleShell } from '@/components/RoleShell';

export default async function StaffLayout({ children }: { children: ReactNode }) {
  const me = await requireRole('staff', 'owner');
  return <RoleShell role={me.role} name={me.fullName}>{children}</RoleShell>;
}
