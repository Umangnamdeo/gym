import { PageHeader } from '@/components/ui/AppShell';
import { EmptyState } from '@/components/ui/States';

export default function OwnerHome() {
  return (
    <>
      <PageHeader title="Owner" />
      <EmptyState title="Coming soon" description="This area is built in Phase 13." />
    </>
  );
}
