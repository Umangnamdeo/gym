import { redirect } from 'next/navigation';
import { Brand } from '@/components/ui/Brand';
import { getCurrentUser, ROLE_HOME } from '@/lib/auth';
import { LoginForm } from './LoginForm';

export const metadata = { title: 'Sign in' };

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const me = await getCurrentUser();
  if (me?.isActive) redirect(ROLE_HOME[me.role]);

  const { error } = await searchParams;
  return (
    <main className="mx-auto flex min-h-dvh max-w-sm flex-col justify-center gap-8 p-6">
      <Brand />
      {error === 'link' && (
        <p role="alert" className="text-sm text-danger">That link is invalid or has expired. Ask the gym to send a new invite.</p>
      )}
      <LoginForm />
    </main>
  );
}
