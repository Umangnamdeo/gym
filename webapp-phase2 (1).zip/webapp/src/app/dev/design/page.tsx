import { notFound } from 'next/navigation';
import { Showcase } from './Showcase';

export const metadata = { title: 'Design system', robots: { index: false, follow: false } };

// Development aid only. Returns 404 in production builds.
export default function DesignPage() {
  if (process.env.NODE_ENV === 'production') notFound();
  return <Showcase />;
}
