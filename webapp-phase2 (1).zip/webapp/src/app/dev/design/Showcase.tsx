'use client';

import { useState, type ReactNode } from 'react';
import { PageHeader } from '@/components/ui/AppShell';
import { Badge, MembershipStatusBadge } from '@/components/ui/Badge';
import { BarChart } from '@/components/ui/BarChart';
import { Brand } from '@/components/ui/Brand';
import { Button } from '@/components/ui/Button';
import { Card, CardTitle } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { MembershipCard } from '@/components/ui/MembershipCard';
import { ConfirmDialog, Modal } from '@/components/ui/Modal';
import { QrCard } from '@/components/ui/QrCard';
import { ReceiptDocument } from '@/components/ui/ReceiptDocument';
import { ScannerFrame } from '@/components/ui/Scanner';
import { Select } from '@/components/ui/Select';
import { Skeleton } from '@/components/ui/Skeleton';
import { OccupancyMeter, StatCard } from '@/components/ui/StatCard';
import { EmptyState, ErrorState } from '@/components/ui/States';
import { DataTable } from '@/components/ui/Table';
import { useToast } from '@/components/ui/Toast';
import type { ScanCode } from '@/lib/scan-codes';

const CODES: ScanCode[] = ['ENTRY_APPROVED', 'EXIT_RECORDED', 'MEMBERSHIP_EXPIRED', 'ALREADY_CHECKED_IN', 'QR_INVALID', 'MEMBER_NOT_FOUND'];
const HOURS = [['05', 12], ['06', 27], ['07', 42], ['08', 31], ['09', 18], ['10', 9], ['17', 24], ['18', 39], ['19', 44], ['20', 28]] as const;
const ROWS = [
  { id: '1', name: 'Sample Member', memberId: 'MS-0001', visits: 42 },
  { id: '2', name: 'Another Member', memberId: 'MS-0002', visits: 17 },
];

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="mb-10">
      <h2 className="mb-3 font-display text-xl font-semibold uppercase tracking-widest text-accent">{title}</h2>
      <div className="space-y-4">{children}</div>
    </section>
  );
}

export function Showcase() {
  const toast = useToast();
  const [modal, setModal] = useState(false);
  const [confirm, setConfirm] = useState(false);
  const [mode, setMode] = useState<'entry' | 'exit'>('entry');
  const [code, setCode] = useState<ScanCode | null>(null);

  return (
    <main className="mx-auto max-w-3xl p-4 pb-24 lg:p-8">
      <PageHeader title="Design system" description="Development page. Not available in production." />

      <Section title="Brand"><Brand /></Section>

      <Section title="Buttons">
        <div className="flex flex-wrap gap-2">
          <Button>Primary</Button>
          <Button variant="secondary">Secondary</Button>
          <Button variant="ghost">Ghost</Button>
          <Button variant="danger">Danger</Button>
          <Button loading>Loading</Button>
          <Button disabled>Disabled</Button>
          <Button size="sm">Small</Button>
          <Button size="lg">Large</Button>
        </div>
      </Section>

      <Section title="Inputs">
        <div className="grid gap-4 sm:grid-cols-2">
          <Input label="Name" placeholder="Full name" />
          <Input label="Phone" hint="10 digit number" />
          <Input label="Email" error="Enter a valid email" defaultValue="bad@" />
          <Select label="Plan"><option>Monthly</option><option>Quarterly</option><option>Yearly</option></Select>
        </div>
      </Section>

      <Section title="Badges">
        <div className="flex flex-wrap gap-2">
          <Badge>Neutral</Badge>
          <Badge tone="accent">Accent</Badge>
          <MembershipStatusBadge state="active" daysRemaining={27} />
          <MembershipStatusBadge state="active" daysRemaining={3} />
          <MembershipStatusBadge state="expired" />
          <MembershipStatusBadge state="disabled" />
        </div>
      </Section>

      <Section title="Dashboard">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          <StatCard label="Total members" value={412} />
          <StatCard label="Active" value={368} tone="accent" />
          <StatCard label="Expiring soon" value={21} tone="warn" />
        </div>
        <OccupancyMeter current={37} capacity={80} />
        <Card>
          <CardTitle>Peak hours</CardTitle>
          <div className="mt-4">
            <BarChart ariaLabel="Members per hour" showValues data={HOURS.map(([label, value]) => ({ label, value }))} />
          </div>
        </Card>
      </Section>

      <Section title="Table">
        <DataTable caption="Sample members" rows={ROWS} rowKey={(r) => r.id} columns={[
          { key: 'name', header: 'Name', cell: (r) => r.name },
          { key: 'id', header: 'Member ID', cell: (r) => r.memberId },
          { key: 'visits', header: 'Visits', align: 'right', cell: (r) => r.visits },
        ]} />
      </Section>

      <Section title="Membership and QR">
        <MembershipCard planName="Quarterly" startDate="2026-09-01" expiryDate="2026-11-30" state="active" daysRemaining={27} />
        <QrCard value={`MS1.${'0'.repeat(64)}`} name="Sample Member" memberId="MS-0001" />
      </Section>

      <Section title="Scanner">
        <ScannerFrame mode={mode} onModeChange={setMode}
          outcome={code ? { code, name: 'Sample Member', memberId: 'MS-0001', daysLeft: 27 } : null}>
          <div className="flex h-full items-center justify-center text-sm text-muted">Camera view (Phase 10)</div>
        </ScannerFrame>
        <div className="flex flex-wrap gap-2">
          {CODES.map((c) => <Button key={c} size="sm" variant="secondary" onClick={() => setCode(c)}>{c}</Button>)}
          <Button size="sm" variant="ghost" onClick={() => setCode(null)}>Reset</Button>
        </div>
      </Section>

      <Section title="Feedback">
        <div className="flex flex-wrap gap-2">
          <Button variant="secondary" onClick={() => toast('Member saved', 'success')}>Success toast</Button>
          <Button variant="secondary" onClick={() => toast('Could not save', 'error')}>Error toast</Button>
          <Button variant="secondary" onClick={() => setModal(true)}>Modal</Button>
          <Button variant="secondary" onClick={() => setConfirm(true)}>Confirm dialog</Button>
        </div>
        <Modal open={modal} onClose={() => setModal(false)} title="Modal" footer={<Button onClick={() => setModal(false)}>Done</Button>}>
          Native dialog: Esc, backdrop click and focus trapping work.
        </Modal>
        <ConfirmDialog open={confirm} title="Disable member?" message="They will no longer be able to enter."
          confirmLabel="Disable" tone="danger"
          onConfirm={() => { setConfirm(false); toast('Member disabled', 'success'); }}
          onCancel={() => setConfirm(false)} />
      </Section>

      <Section title="States">
        <div className="grid gap-3 sm:grid-cols-3"><Skeleton className="h-24" /><Skeleton className="h-24" /><Skeleton className="h-24" /></div>
        <EmptyState title="No members yet" description="Add your first member to get started." action={<Button>Add member</Button>} />
        <ErrorState message="We could not load the members. Check your connection." action={<Button variant="secondary">Try again</Button>} />
      </Section>

      <Section title="Receipt (A4)">
        <ReceiptDocument
          brand={{ gymName: 'THE MUSCLE SCHOOL - SAHIL FITNESS', address: 'Baliyari Road, near Mishra Polyclinic, Waidhan, Madhya Pradesh 486886', phone: '086028 93459', footer: 'Thank you for training with us.' }}
          receipt={{ number: 'RCPT-2026-0001', date: '2026-09-29', memberName: 'Sample Member', memberId: 'MS-0001', phone: '9000000000', planName: 'Quarterly', startDate: '2026-09-01', expiryDate: '2026-11-30', description: 'Quarterly membership', amount: 3000, authorizedBy: 'Owner' }}
        />
      </Section>
    </main>
  );
}
