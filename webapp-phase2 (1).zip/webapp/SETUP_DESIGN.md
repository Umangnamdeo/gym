# Phase 2 setup (Design system)

```bash
npm i qrcode
npm i -D @types/qrcode
```
Copy `src/` from `webapp/` over your project. These files REPLACE the create-next-app defaults: `src/app/globals.css` and `src/app/layout.tsx`. The default `src/app/page.tsx` stays until Phase 3.

This assumes **Tailwind v4** (what `create-next-app@15` installs now): tokens live in `globals.css` under `@theme`. If your project has a `tailwind.config.js`, it is v3, so tell me and I will adapt the tokens.

Preview everything at `http://localhost:3000/dev/design` (404 in production builds; removed in Phase 25).

## Where things are
- Colors, radius, fonts: `src/app/globals.css` (accent is one variable: `--color-accent`)
- Components: `src/components/ui/*`
- Navigation items per role: `src/lib/nav.ts` (each phase adds its own entries, so there are no dead links)
- Scanner result codes: `src/lib/scan-codes.ts` (match the `record_scan` database function)
