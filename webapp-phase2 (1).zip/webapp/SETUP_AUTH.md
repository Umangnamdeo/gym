# Phase 5 setup (Authentication)

## 1. Create the app
```bash
npx create-next-app@15 muscle-school --ts --tailwind --app --src-dir --eslint --import-alias "@/*"
cd muscle-school
npm i @supabase/supabase-js @supabase/ssr zod server-only
```
Copy `src/` and `.env.example` from `webapp/` into the project, copy `.env.example` to `.env.local`, and fill in the three values. Put `supabase/migrations/0001_muscle_school_schema.sql` in the project too.

## 2. Supabase dashboard
1. **Authentication > Sign In / Providers > Email:** turn OFF "Allow new users to sign up". Accounts are created only by owner invite.
2. **Authentication > URL Configuration:** set Site URL to your domain (`http://localhost:3000` for dev).
3. **Authentication > Email Templates > Invite user:** change the link to
   `{{ .SiteURL }}/auth/confirm?token_hash={{ .TokenHash }}&type=invite`
4. **Authentication > SMTP:** configure a real SMTP provider. The built-in mailer allows only a few emails per hour, which will break invites.
5. **Authentication > Sessions / JWT:** keep JWT expiry at 3600 s. Inactivity timeout and time-boxed sessions are plan-dependent settings there.
6. **Authentication > Password:** minimum length 10.

## 3. First owner
Create the owner in **Authentication > Users** (Add user, auto-confirm), copy the UUID, then run in the SQL editor:
```sql
insert into public.users(id, role, full_name) values ('<UUID>', 'owner', 'Owner Name');
```

## 4. Try it
`npm run dev`, open `/login`, sign in as the owner. `/owner` should be blocked for staff and members, `/staff` for members, and `/member` for owner and staff.
